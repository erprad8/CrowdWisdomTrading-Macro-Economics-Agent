"""A minimal, framework-free tool-use loop on the Anthropic Messages API."""
import json
import os

import anthropic

from agents.tools import TOOLS, TOOL_SPECS

MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5")   # verify the current ID in Anthropic's docs


def make_client():
    return anthropic.Anthropic()   # reads ANTHROPIC_API_KEY


def run_agent(client, state, name, system, tool_names, task, max_turns=8, model=MODEL):
    specs = [TOOL_SPECS[t] for t in tool_names]
    messages = [{"role": "user", "content": task}]
    for _ in range(max_turns):
        resp = client.messages.create(model=model, max_tokens=2000, system=system, tools=specs, messages=messages)
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")
        results = []
        for b in resp.content:
            if b.type != "tool_use":
                continue
            if b.name not in tool_names:                      # least privilege: agent may only call its own tools
                out, err = {"error": f"tool {b.name} not allowed for {name}"}, True
            else:
                try:
                    out, err = TOOLS[b.name](state, **b.input), False
                except Exception as e:                        # surface failures to the model instead of crashing
                    out, err = {"error": f"{type(e).__name__}: {e}"}, True
            state.audit.append((name, b.name, b.input, not err))
            results.append({"type": "tool_result", "tool_use_id": b.id, "is_error": err,
                            "content": json.dumps(out, default=str)[:6000]})
        messages.append({"role": "user", "content": results})
    raise RuntimeError(f"{name}: exceeded {max_turns} turns")
