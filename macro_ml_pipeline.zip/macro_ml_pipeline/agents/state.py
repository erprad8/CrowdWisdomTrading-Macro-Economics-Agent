"""Shared run state. DataFrames live here, NOT in the LLM context: tools return compact JSON summaries."""
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class State:
    demo: bool = True
    trades_path: Optional[str] = None
    horizon_days: int = 15
    events: Any = None        # DataFrame: normalised calendar + sentiment
    news: Any = None
    trades: Any = None
    model_table: Any = None
    preds: Any = None
    folds: Any = None
    rec: Any = None
    facts: dict = field(default_factory=dict)
    outlook_md: str = ""
    charts: list = field(default_factory=list)
    audit: list = field(default_factory=list)   # (agent, tool, args, ok) for every tool call
