"""Deterministic tools the agents can call. Each takes (state, **args) and returns a small JSON-able dict."""
import re
from datetime import datetime, timedelta, timezone

import pandas as pd

import config as C
import database as db
import evaluation as E
import ingest_events as ie
import ingest_trades as it
import model as M
import visuals as V
from features import build_context_features
from ingest_events import sentiment_at


def _now():
    return datetime.now(timezone.utc)


def collect_calendar(s, lookback_days: int = C.LOOKBACK_DAYS):
    start, end = _now() - timedelta(days=lookback_days), _now() + timedelta(days=s.horizon_days + 7)
    raw = ie.synthetic_calendar(start - timedelta(days=45), end) if s.demo else ie.fetch_calendar_apify(start, end)
    s.events = ie.add_sentiment(ie.normalize_calendar(raw))
    ev = s.events
    return {"rows": len(ev), "released": int(ev["actual"].notna().sum()),
            "first": str(ev["ts_utc"].min()), "last": str(ev["ts_utc"].max()),
            "by_family": ev["family"].value_counts().to_dict()}


def collect_news(s, days: int = 7):
    s.news = ie.synthetic_news() if s.demo else ie.fetch_news_tavily(days=days)
    n = s.news
    return {"articles": len(n), "mean_tone": round(float(n["sentiment"].mean()), 3) if len(n) else None,
            "titles": n["title"].head(5).tolist()}


def load_trades(s):
    start = _now() - timedelta(days=C.LOOKBACK_DAYS)
    t = it.synthetic_trades(start, _now(), s.events) if s.demo else it.load_trades(s.trades_path)
    s.trades = t[t["entry_time"] >= pd.Timestamp(start)].reset_index(drop=True)
    return {"trades": len(s.trades), "permutations": int(s.trades["perm_id"].nunique()),
            "params": it.param_cols(s.trades), "from": str(s.trades["entry_time"].min()), "to": str(s.trades["entry_time"].max())}


def build_features(s):
    db.save("events", s.events); db.save("trades", s.trades); db.save("news", s.news)
    db.create_views()
    ctx = build_context_features(s.trades["entry_time"], s.events)
    db.save("model_table", pd.concat([s.trades.reset_index(drop=True), ctx], axis=1))
    s.model_table = db.load("model_table")
    return {"rows": len(s.model_table), "n_features": len(M.feature_cols(s.model_table)),
            "features": M.feature_cols(s.model_table)}


def run_walk_forward(s):
    s.preds, s.folds = M.walk_forward(s.model_table)
    f = s.folds
    out = {"n_folds": len(f),
           "rmse_model": round(f.rmse_model.mean(), 4), "rmse_base": round(f.rmse_base.mean(), 4),
           "auc_win": round(f.auc_win.mean(), 4),
           "topk_model": round(f.topk_model.mean(), 4), "topk_base": round(f.topk_base.mean(), 4),
           "all_perm_avg": round(f.all_perm_avg.mean(), 4),
           "rank_corr_model": round(f.rank_corr_model.mean(), 4), "rank_corr_base": round(f.rank_corr_base.mean(), 4)}
    out["model_beats_baseline_on_topk"] = bool(out["topk_model"] > out["topk_base"])
    out["model_beats_baseline_on_rmse"] = bool(out["rmse_model"] < out["rmse_base"])
    return out


def recommend_permutations(s, top_n: int = 5):
    pcols = it.param_cols(s.model_table)
    perms = s.model_table[pcols].drop_duplicates().reset_index(drop=True)
    s.rec, _ = M.recommend(M.final_model(s.model_table), s.events, perms, s.horizon_days)
    s.rec["perm_id"] = s.rec[pcols].astype(str).agg("|".join, axis=1)
    s.rec.to_csv(C.OUT / "recommended_permutations.csv", index=False)
    return {"top": s.rec.head(top_n)[["perm_id", "pred_pnl", "pred_win"]].round(4).to_dict("records")}


def get_macro_facts(s):
    now = pd.Timestamp.now(tz="UTC")
    ev = s.events
    cur = float(sentiment_at([now], ev).iloc[0]); ago = float(sentiment_at([now - pd.Timedelta(days=30)], ev).iloc[0])
    rel = ev[ev.actual.notna() & ev.family.notna() & ev.surprise_z.notna()].tail(6)
    up = ev[(ev.ts_utc > now) & (ev.ts_utc <= now + pd.Timedelta(days=14)) & (ev.impact == "high")].head(6)
    s.facts = {
        "sentiment_now": round(cur, 2), "sentiment_30d_ago": round(ago, 2),
        "regime": "risk-supportive" if cur > .5 else "hawkish" if cur < -.5 else "neutral",
        "latest_releases": [dict(date=f"{r.ts_utc:%Y-%m-%d}", event=r.title, actual=r.actual, forecast=r.forecast,
                                 surprise_z=round(r.surprise_z, 1)) for r in rel.itertuples()],
        "upcoming_high_impact": [dict(utc=f"{r.ts_utc:%Y-%m-%d %H:%M}", est=f"{r.ts_est:%H:%M}", event=r.title) for r in up.itertuples()],
        "news_titles": s.news["title"].head(5).tolist() if s.news is not None else [],
        "news_mean_tone": round(float(s.news["sentiment"].mean()), 2) if s.news is not None and len(s.news) else None,
        "top_permutations": s.rec.head(3)[["perm_id", "pred_pnl", "pred_win"]].round(3).to_dict("records") if s.rec is not None else [],
        "oos": {k: round(float(s.folds[k].mean()), 3) for k in ("topk_model", "topk_base", "all_perm_avg")} if s.folds is not None else {}}
    return s.facts


def write_outlook(s, markdown: str):
    words = len(markdown.split())
    if words > 450:
        return {"saved": False, "error": f"{words} words; limit is 450 for one page. Shorten and call again."}
    s.outlook_md = markdown
    (C.OUT / "macro_outlook_agent.md").write_text(markdown)
    return {"saved": True, "words": words}


def check_outlook_numbers(s):
    """Flag numbers in the outlook that do not appear in the facts the analyst was given."""
    blob = str(s.facts)
    nums = set(re.findall(r"\d+(?:\.\d+)?", s.outlook_md))
    bad = sorted(n for n in nums if n not in blob and not (len(n) == 4 and n.startswith("20")) and n not in {"1", "14", "30", "7"})
    return {"unmatched_numbers": bad, "ok": not bad}


def render_charts(s):
    s.charts = [p.name for p in V.make_all(s.events, s.model_table, s.preds, s.folds)]
    E.write_report(s.preds, s.folds, s.demo)      # evaluation_report.md + 06_equity_curves.png
    return {"charts": s.charts}


def _obj(props=None, req=None):
    return {"type": "object", "properties": props or {}, "required": req or []}


TOOLS = {"collect_calendar": collect_calendar, "collect_news": collect_news, "load_trades": load_trades,
         "build_features": build_features, "run_walk_forward": run_walk_forward,
         "recommend_permutations": recommend_permutations, "get_macro_facts": get_macro_facts,
         "write_outlook": write_outlook, "check_outlook_numbers": check_outlook_numbers, "render_charts": render_charts}

TOOL_SPECS = {
    "collect_calendar": dict(name="collect_calendar", description="Scrape (or in demo mode simulate) the USD macro calendar for the lookback window and store normalised events. Call once.",
                             input_schema=_obj({"lookback_days": {"type": "integer"}})),
    "collect_news": dict(name="collect_news", description="Fetch recent macro news via Tavily and score tone. Returns headlines and mean tone.",
                         input_schema=_obj({"days": {"type": "integer"}})),
    "load_trades": dict(name="load_trades", description="Load the trading log and list strategy permutations.", input_schema=_obj()),
    "build_features": dict(name="build_features", description="Join trades with macro events in SQLite and build point-in-time features.", input_schema=_obj()),
    "run_walk_forward": dict(name="run_walk_forward", description="Run walk-forward validation. Returns OOS metrics and whether the model beats the history-mean baseline.", input_schema=_obj()),
    "recommend_permutations": dict(name="recommend_permutations", description="Score all permutations for the next horizon; returns the top N.",
                                   input_schema=_obj({"top_n": {"type": "integer"}})),
    "get_macro_facts": dict(name="get_macro_facts", description="Return the verified facts (sentiment, releases, upcoming events, news, model results) to base the outlook on.", input_schema=_obj()),
    "write_outlook": dict(name="write_outlook", description="Save the one-page outlook (Markdown, max 450 words).",
                          input_schema=_obj({"markdown": {"type": "string"}}, ["markdown"])),
    "check_outlook_numbers": dict(name="check_outlook_numbers", description="Check every number in the saved outlook against the facts. Returns unmatched numbers.", input_schema=_obj()),
    "render_charts": dict(name="render_charts", description="Render the five charts to the output folder.", input_schema=_obj()),
}
