"""Scripted stand-in for the Anthropic client so the agent plumbing can be tested offline and for free."""
import json
from types import SimpleNamespace as NS


def text(t): return NS(type="text", text=t)
def call(i, name, **inp): return NS(type="tool_use", id=f"tu_{i}", name=name, input=inp)


class FakeClient:
    def __init__(self):
        self.messages = self
        self.step = {}

    def create(self, model, max_tokens, system, tools, messages):
        names = [t["name"] for t in tools]
        k = sum(1 for m in messages if m["role"] == "assistant")      # how many turns this agent has taken
        if "collect_calendar" in names:
            plan = ["collect_calendar", "collect_news", "load_trades"]
        elif "build_features" in names:
            plan = ["build_features", "run_walk_forward", "recommend_permutations"]
        else:
            plan = ["get_macro_facts", "WRITE", "check_outlook_numbers"]
        if k < len(plan):
            n = plan[k]
            if n == "WRITE":
                facts = json.loads(messages[-1]["content"][0]["content"])
                md = (f"# Outlook\n## Regime\nRegime is {facts['regime']} with sentiment {facts['sentiment_now']}.\n"
                      f"## Model view\nTop permutation {facts['top_permutations'][0]['perm_id']}.")
                return NS(stop_reason="tool_use", content=[call(k, "write_outlook", markdown=md)])
            return NS(stop_reason="tool_use", content=[call(k, n)])
        return NS(stop_reason="end_turn", content=[text("done")])
