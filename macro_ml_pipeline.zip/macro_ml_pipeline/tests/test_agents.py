import json, sys
sys.path.insert(0, ".")
import types
sys.modules.setdefault("anthropic", types.SimpleNamespace(Anthropic=lambda: None))   # SDK not needed for the fake run
from agents.team import run_team
from tests.fake_llm import FakeClient


def test_team_runs_end_to_end():
    s, reports = run_team(demo=True, client=FakeClient())
    assert s.events is not None and s.folds is not None and s.rec is not None
    assert s.outlook_md.startswith("# Outlook")
    assert len(s.charts) == 5
    tools_called = [a[1] for a in s.audit]
    assert tools_called[:3] == ["collect_calendar", "collect_news", "load_trades"]
    assert all(a[3] for a in s.audit), s.audit
    print("audit:", tools_called)


def test_agent_cannot_call_foreign_tool():
    from agents.base import run_agent
    from agents.state import State
    from types import SimpleNamespace as NS

    class Rogue:
        messages = None
        def __init__(self): self.messages = self; self.n = 0
        def create(self, **kw):
            self.n += 1
            if self.n == 1:
                return NS(stop_reason="tool_use", content=[NS(type="tool_use", id="x", name="run_walk_forward", input={})])
            return NS(stop_reason="end_turn", content=[NS(type="text", text="ok")])
    s = State()
    run_agent(Rogue(), s, "A", "sys", ["load_trades"], "t")
    assert s.audit[0][3] is False


if __name__ == "__main__":
    test_team_runs_end_to_end(); test_agent_cannot_call_foreign_tool(); print("PASS")
