# Outlook
## Regime
Regime is hawkish with sentiment -0.7.
## Model view
Top permutation 10.0|2.0|3.0.