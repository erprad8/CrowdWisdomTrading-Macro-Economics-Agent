# Macro Outlook - 09 Oct 2026

> **DEMO MODE:** events, news and trades are synthetic. Do not trade on this page.

**Regime:** HAWKISH / RISK-OFF (state -0.70; 30 days ago +1.17, change -1.86). State = decayed sum of signed CPI/NFP/FOMC/labour surprises; sign convention assumes strong data = tighter policy.

## Latest releases (actual vs forecast)
| Date (UTC) | Event | Actual | Forecast | Surprise (z) |
|---|---|---|---|---|
| 19 Aug | Federal Funds Rate | 4.5 | 4.5 | +0.0 |
| 04 Sep | Average Hourly Earnings m/m | 0.3 | 0.3 | +0.0 |
| 04 Sep | Unemployment Rate | 4.1 | 4.2 | -1.0 |
| 04 Sep | Non-Farm Employment Change | 29000 | 180000 | -3.0 |
| 30 Sep | Federal Funds Rate | 4.6 | 4.5 | +0.4 |
| 02 Oct | Unemployment Rate | 4 | 4.2 | -2.0 |
| 02 Oct | Average Hourly Earnings m/m | 0.3 | 0.3 | +0.0 |
| 02 Oct | Non-Farm Employment Change | 187000 | 180000 | +0.1 |

## Next 14 days - high-impact (UTC / US Eastern)
- Mon 12 Oct 12:30 / 08:30 - CPI m/m (fcst 0.3)
- Mon 12 Oct 12:30 / 08:30 - Core CPI m/m (fcst 0.3)

## News flow (Tavily; mean lexicon tone +0.00, +ve = dovish)
- DEMO: Inflation cooling but services prices sticky, Fed signals patience (+0)
- DEMO: Payrolls come in softer than expected, rate cut bets rise (+1)
- DEMO: Hotter CPI revives higher for longer concerns (-1)

## Model view - top permutations, next horizon (walk-forward OOS over 6 windows)
- `10.0|2.0|3.0`: predicted P&L/trade +0.128, win prob 59.1%
- `20.0|2.0|3.0`: predicted P&L/trade +0.128, win prob 59.1%
- `50.0|2.0|3.0`: predicted P&L/trade +0.122, win prob 58.5%
- OOS evidence: model top-3 averaged +0.135/trade vs +0.250 for history-mean and +0.034 for all permutations; rank-corr +0.24 vs +0.22.

*Research output, not investment advice. Sentiment weights and the lexicon news score are simple heuristics.*